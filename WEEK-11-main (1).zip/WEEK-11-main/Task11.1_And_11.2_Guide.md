# Task 11.1 & 11.2 Guide

## Task 11.1: Jenkins Installation & Freestyle Job

### 1. Install Jenkins on local system
1. Download Jenkins from `https://www.jenkins.io/download/` (choose the Windows `.msi` native installer or generic `.war` file).
2. Follow the installer instructions. If it's a `.war`, run `java -jar jenkins.war` from your command prompt.
3. Jenkins will start on `http://localhost:8080`.

### 2. Unlock Jenkins and configure admin user
1. Open your browser to `http://localhost:8080`.
2. Find the initial admin password from the location shown on the screen (e.g., `C:\ProgramData\Jenkins\.jenkins\secrets\initialAdminPassword`).
3. Enter the password and click "Continue".
4. Create your first admin user when prompted.

### 3. Install recommended plugins
1. Choose "Install suggested plugins" in the setup wizard.
2. Wait for the plugins to download and install.

### 4. Create first Freestyle job
1. Go to the Jenkins dashboard and click "New Item".
2. Enter a name (e.g., `My First Freestyle Job`) and select "Freestyle project", then click "OK".
3. Under "Build", add a build step "Execute Windows batch command" (since you are on Windows) and type: `echo Hello Jenkins!`.
4. Click "Save".

### 5. Execute a simple build and view console output
1. Click "Build Now" on the job's page.
2. Once the build finishes (you'll see a green checkmark or blue ball under Build History), click the build number.
3. Click "Console Output" to view the log and verify your message is printed.

---

## Task 11.2: Connect Jenkins with GitHub repository

Before starting, push this `week11` directory to a new public GitHub repository.

### 1. Connect Jenkins with GitHub repository & 2. Configure SCM in Jenkins job
1. Go to your Jenkins Dashboard -> "New Item".
2. Enter a name (e.g., `GitHub-Integration-Job`) and select "Freestyle project".
3. Under the "Source Code Management" tab, select **Git**.
4. Paste your GitHub repository URL (e.g., `https://github.com/your-username/week11.git`).
5. Change the branch specifier to `*/main` (or whatever your default branch is).

### 3. Pull source code from GitHub
1. In the build steps, add "Execute Windows batch command" and type:
   ```cmd
   echo "Code is pulled automatically."
   dir
   ```
2. Click "Save".

### 4. Trigger build manually after commit
1. Click "Build Now" manually to verify Jenkins successfully pulls the source code from your repository.

### 5. Configure GitHub webhook for auto build
1. Go to your repository on GitHub.com -> **Settings** -> **Webhooks**.
2. Click **Add webhook**.
3. For Payload URL, enter your Jenkins URL followed by `/github-webhook/` (e.g., `http://your-ip:8080/github-webhook/`). Ensure your Jenkins server is publicly accessible (you might need ngrok if running locally).
4. Select `application/json` as the content type.
5. Back in Jenkins, in your job configuration, check **GitHub hook trigger for GITScm polling** under "Build Triggers".
6. Push a new commit to your repository to see Jenkins build automatically.
