package com.week11;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class AppTest {
    
    @Test
    public void testGetMessage() {
        App app = new App();
        assertEquals("Hello Jenkins Pipeline!", app.getMessage());
    }

    @Test
    public void testAdd() {
        App app = new App();
        assertEquals(5, app.add(2, 3));
    }
}
