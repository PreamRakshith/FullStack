package com.week11;

public class App {
    public String getMessage() {
        return "Hello Jenkins Pipeline!";
    }

    public int add(int a, int b) {
        return a + b;
    }

    public static void main(String[] args) {
        App app = new App();
        System.out.println(app.getMessage());
    }
}
