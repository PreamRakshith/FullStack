# Session 58 – GitLab CI Pipeline Basics

**Reference:** https://docs.gitlab.com/ee/ci/pipelines/

---

## Objective

By the end of this session you will:
- Define `build` and `test` stages in a pipeline.
- Write multiple CI jobs in `.gitlab-ci.yml`.
- Use GitLab's shared runners.
- View the visual pipeline execution graph.
- Check job logs and exit status.

---

## Task 1: Define Pipeline Stages – `build` and `test`

Update your `.gitlab-ci.yml` to a more realistic pipeline.

Open **Edit → Web IDE** in your project, click on `.gitlab-ci.yml`, and replace the contents with:

```yaml
# .gitlab-ci.yml – Session 58: Pipeline Basics with build & test stages
# Reference: https://docs.gitlab.com/ee/ci/pipelines/

image: maven:3.8.6-openjdk-11   # Use the official Maven+JDK Docker image

stages:
  - build
  - test

# ─── BUILD STAGE ────────────────────────────────────────────────────────────

compile-app:
  stage: build
  script:
    - echo "Compiling Java source code with Maven..."
    - mvn compile -B          # -B = batch/non-interactive mode
  artifacts:
    paths:
      - target/classes/       # Save compiled classes for the test stage
    expire_in: 1 hour

# ─── TEST STAGE ─────────────────────────────────────────────────────────────

unit-tests:
  stage: test
  script:
    - echo "Running unit tests with Maven..."
    - mvn test -B
  # Pipeline fails automatically if mvn test exits with a non-zero code
```

Commit with message: `Session 58 – pipeline basics with build and test jobs`.

---

## Task 2: Write the First CI Job – Key Concepts

Every job block follows this structure:

```yaml
job-name:          # Unique name for the job (visible in the UI)
  stage: build     # Which stage this job belongs to
  image: ...       # (optional) Docker image to run the job inside
  script:          # Commands to execute (required)
    - command1
    - command2
  artifacts:       # (optional) Files to save after the job finishes
    paths:
      - target/
```

Key rules:
- Jobs in the **same stage** run **in parallel**.
- Jobs in the **next stage** only start after all jobs in the current stage pass.
- If any `script` command exits with a non-zero code → the job **fails** → the pipeline stops.

---

## Task 3: GitLab Shared Runners

GitLab provides **free shared runners** for public projects. These are cloud-hosted virtual machines that execute your jobs.

How to verify a runner is attached:
1. Go to **Settings → CI/CD** in your project.
2. Expand the **Runners** section.
3. You should see a list of **Shared runners** with green dots (active).

Key facts:
| Fact | Detail |
|------|--------|
| **Runner type** | Shared (managed by GitLab.com), no setup needed |
| **Executor** | Docker – each job runs in a fresh container |
| **Cost** | Free tier: 400 CI/CD minutes per month |
| **Image selection** | Controlled by the `image:` keyword in your YAML |

> **Why `image: maven:3.8.6-openjdk-11`?** This Docker image already has Maven and Java 11 installed, so `mvn compile` and `mvn test` work without any manual installation.

---

## Task 4: View the Pipeline Execution Graph

1. Go to **Build → Pipelines** after your commit.
2. Click the latest pipeline entry.
3. You will see the **visual pipeline graph**:

```
 Stage: build          Stage: test
 ┌──────────────┐      ┌──────────────┐
 │ compile-app  │ ──►  │  unit-tests  │
 │   ✅ passed  │      │   ✅ passed  │
 └──────────────┘      └──────────────┘
```

- Green circle: job **passed**.
- Red circle: job **failed**.
- Grey circle: job **pending** (waiting for a runner).
- Blue circle: job currently **running**.

---

## Task 5: Check Job Logs and Status

1. In the pipeline graph, click **`compile-app`**.
2. The **job log** opens – a live terminal showing every command and its output.
3. Look for these lines at the end:
   ```
   $ mvn compile -B
   [INFO] BUILD SUCCESS
   Job succeeded
   ```
4. Click the **back arrow** and open **`unit-tests`**.
5. Look for:
   ```
   Tests run: 8, Failures: 0, Errors: 0, Skipped: 0
   [INFO] BUILD SUCCESS
   Job succeeded
   ```

### Exit codes (shown in the job log header):
| Exit code | Meaning |
|-----------|---------|
| `0`       | Success |
| Non-zero  | Failure – pipeline is marked as **failed** |

---

## ✅ Checklist

- [ ] Updated `.gitlab-ci.yml` with `build` and `test` stages
- [ ] Added `compile-app` job (build stage) and `unit-tests` job (test stage)
- [ ] Committed changes – pipeline auto-triggered
- [ ] Verified shared runner is active in **Settings → CI/CD → Runners**
- [ ] Viewed the visual pipeline graph in **Build → Pipelines**
- [ ] Opened individual job logs and confirmed successful output
