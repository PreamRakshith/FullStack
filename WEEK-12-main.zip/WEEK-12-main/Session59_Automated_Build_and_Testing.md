# Session 59 – Automated Build & Testing

**Reference:** https://docs.gitlab.com/ee/ci/testing/

---

## Objective

By the end of this session you will:
- Run JUnit unit tests automatically in the CI pipeline.
- Configure the pipeline to fail when a test fails.
- Generate JUnit XML test reports visible inside GitLab.
- Store build artifacts (compiled JAR).
- Download artifacts from the GitLab UI.

---

## Task 1: Integrate Unit Tests into the Pipeline

The unit tests are already written in `src/test/java/com/week12/AppTest.java` (included in this project).

Update `.gitlab-ci.yml` to this full version (open Web IDE → replace contents):

```yaml
# .gitlab-ci.yml – Session 59: Automated Build & Testing
# Reference: https://docs.gitlab.com/ee/ci/testing/

image: maven:3.8.6-openjdk-11

stages:
  - build
  - test

# ════════════════════════════════════════
# BUILD STAGE
# ════════════════════════════════════════
compile-and-package:
  stage: build
  script:
    - echo "=== Compiling and packaging the application ==="
    - mvn package -DskipTests -B
    - echo "Package complete. JAR located at target/"
  artifacts:
    name: "build-artifact-${CI_COMMIT_SHORT_SHA}"
    paths:
      - target/*.jar          # Save the packaged JAR file
    expire_in: 7 days         # Keep artifacts for 7 days

# ════════════════════════════════════════
# TEST STAGE
# ════════════════════════════════════════
run-unit-tests:
  stage: test
  script:
    - echo "=== Running JUnit 5 unit tests ==="
    - mvn test -B
    - echo "=== Tests complete ==="
  # Task 3: Generate JUnit XML reports for GitLab's Test Report UI
  artifacts:
    when: always              # Save reports even when tests FAIL
    reports:
      junit: target/surefire-reports/TEST-*.xml    # JUnit XML format
    paths:
      - target/surefire-reports/    # Also store raw report files
    expire_in: 7 days
  # Task 2: Pipeline automatically FAILS if mvn test exits non-zero
  allow_failure: false        # This is the default – pipeline stops on failure
```

Commit with message: `Session 59 – automated testing with JUnit reports and artifacts`.

---

## Task 2: Configure Pipeline to Fail on Test Failure

By default, if any `script:` command returns a non-zero exit code, the job **fails** and the pipeline stops. You do **not** need any special configuration for this.

To demonstrate a failing test, you could temporarily add a broken test:

```java
@Test
void testThatFails() {
    assertEquals(99, app.add(1, 1), "This will fail on purpose");
}
```

After pushing, the `run-unit-tests` job will show:
```
Tests run: 9, Failures: 1, Errors: 0
[ERROR] BUILD FAILURE
```
And the pipeline badge turns **red**. This proves the pipeline correctly fails.

> **Remember to revert** the broken test before continuing to Session 60.

---

## Task 3: Generate Test Reports (JUnit Format)

The key lines in the YAML above:
```yaml
artifacts:
  reports:
    junit: target/surefire-reports/TEST-*.xml
```

This tells GitLab to parse the XML files produced by Maven Surefire and display them in the GitLab UI.

### How to view test reports in GitLab:
1. Go to **Build → Pipelines** → click your latest pipeline.
2. Click the **`run-unit-tests`** job.
3. Scroll down in the job log to see the test summary.
4. Go back to the **pipeline overview page** – click the **"Tests" tab** at the top.
5. You will see a table with each test method, its status (passed/failed), and execution time.

### What Maven Surefire produces:
- XML files in `target/surefire-reports/TEST-com.week12.AppTest.xml`
- Each `<testcase>` element = one `@Test` method.
- GitLab reads these and renders a visual report.

---

## Task 4: Store Build Artifacts Using `artifacts` Keyword

The `artifacts:` block in the `compile-and-package` job does two things:

```yaml
artifacts:
  name: "build-artifact-${CI_COMMIT_SHORT_SHA}"  # Name includes the commit hash
  paths:
    - target/*.jar          # Glob pattern – saves any .jar file
  expire_in: 7 days         # Auto-deleted after 7 days (saves storage)
```

**Predefined CI variables used:**
| Variable | Value example |
|---------|---------------|
| `CI_COMMIT_SHORT_SHA` | `a1b2c3d` – first 7 chars of the commit hash |
| `CI_PROJECT_NAME` | `gitlab-cicd-demo` |
| `CI_PIPELINE_ID` | `12345` |

---

## Task 5: Download Artifacts from GitLab UI

1. Go to **Build → Pipelines** → click your latest (green) pipeline.
2. Click **`compile-and-package`** job.
3. On the **right sidebar** of the job page, look for the **Artifacts** section.
4. Click **"Download artifacts"** – this downloads a `.zip` file.
5. Unzip it → you will find `target/gitlab-cicd-tasks-1.0-SNAPSHOT.jar`.

Alternatively, from the **pipeline overview**:
1. Click the **download icon** (⬇) on the right side of any job row.
2. This also downloads the artifact ZIP directly.

---

## ✅ Checklist

- [ ] Updated `.gitlab-ci.yml` with `compile-and-package` (build) and `run-unit-tests` (test) jobs
- [ ] Understood how `allow_failure: false` causes pipeline to stop on test failure
- [ ] Added `reports: junit:` section to upload JUnit XML test results
- [ ] Viewed the **Tests tab** in the pipeline overview with per-test results
- [ ] Confirmed the JAR is stored as an artifact using `artifacts: paths:`
- [ ] Downloaded the artifact ZIP from the GitLab job page
