# Session 60 – CI/CD Deployment & Environments

**Reference:** https://docs.gitlab.com/ee/ci/environments/

---

## Objective

By the end of this session you will:
- Deploy the application to a **staging** environment via the pipeline.
- Configure GitLab **Environments** (staging, production).
- Add a **manual approval** job for production deployment.
- Use **CI variables** for environment selection.
- Monitor deployments and pipeline history.

---

## Task 1 & 2: Deploy to Staging + Configure Environments

Replace your `.gitlab-ci.yml` with the **full Session 60 pipeline** below.

Open **Edit → Web IDE** → click `.gitlab-ci.yml` → replace all contents:

```yaml
# .gitlab-ci.yml – Session 60: Deployment & Environments
# Reference: https://docs.gitlab.com/ee/ci/environments/

image: maven:3.8.6-openjdk-11

# ─── STAGES ──────────────────────────────────────────────────────────────────
stages:
  - build
  - test
  - deploy-staging
  - deploy-production

# ─── CI VARIABLES (Task 4) ───────────────────────────────────────────────────
variables:
  STAGING_URL:    "https://staging.gitlab-cicd-demo.example.com"
  PRODUCTION_URL: "https://gitlab-cicd-demo.example.com"
  APP_NAME:       "gitlab-cicd-demo"

# ════════════════════════════════════════
# BUILD STAGE
# ════════════════════════════════════════
compile-and-package:
  stage: build
  script:
    - echo "Building $APP_NAME..."
    - mvn package -DskipTests -B
  artifacts:
    name: "build-${CI_COMMIT_SHORT_SHA}"
    paths:
      - target/*.jar
    expire_in: 1 day

# ════════════════════════════════════════
# TEST STAGE
# ════════════════════════════════════════
run-unit-tests:
  stage: test
  script:
    - mvn test -B
  artifacts:
    when: always
    reports:
      junit: target/surefire-reports/TEST-*.xml
    expire_in: 7 days

# ════════════════════════════════════════
# DEPLOY TO STAGING (Task 1 & 2)
# ════════════════════════════════════════
deploy-staging:
  stage: deploy-staging
  script:
    - echo "========================================"
    - echo "  DEPLOYING TO STAGING ENVIRONMENT"
    - echo "  App     : $APP_NAME"
    - echo "  URL     : $STAGING_URL"
    - echo "  Commit  : $CI_COMMIT_SHORT_SHA"
    - echo "  Branch  : $CI_COMMIT_REF_NAME"
    - echo "========================================"
    - echo "Simulating deployment... (copy JAR, restart service)"
    - echo "Deployment to STAGING complete."
  environment:
    name: staging                   # GitLab Environments name
    url: $STAGING_URL               # Clickable URL in the Environments UI
  only:
    - main                          # Only deploy when pushing to main branch

# ════════════════════════════════════════
# DEPLOY TO PRODUCTION (Task 3 – Manual Approval)
# ════════════════════════════════════════
deploy-production:
  stage: deploy-production
  script:
    - echo "========================================"
    - echo "  DEPLOYING TO PRODUCTION ENVIRONMENT"
    - echo "  App     : $APP_NAME"
    - echo "  URL     : $PRODUCTION_URL"
    - echo "  Commit  : $CI_COMMIT_SHORT_SHA"
    - echo "========================================"
    - echo "Simulating production deployment..."
    - echo "Production deployment COMPLETE."
  environment:
    name: production                # Separate 'production' environment in GitLab
    url: $PRODUCTION_URL
  when: manual                      # Requires a human to click 'Run' in the UI
  allow_failure: false              # If declined, it does NOT mark the pipeline failed
  only:
    - main
```

Commit with message: `Session 60 – deployment to staging and production with manual approval`.

---

## Task 3: Manual Approval Job for Production Deploy

The critical line is:
```yaml
when: manual
```

This means the `deploy-production` job **will NOT run automatically**. Instead:

1. After the pipeline finishes `deploy-staging`, you will see a **▶ (play button)** next to the `deploy-production` job in the pipeline graph.
2. Click the **▶ play button** to trigger it manually.
3. You will see a confirmation dialog – click **OK / Trigger this manual action**.
4. The production deploy job then runs.

This simulates a **Change Approval** process in real deployments, where a team lead or DevOps engineer must review and approve before going live.

---

## Task 4: Use CI Variables for Environment Selection

### Predefined variables (auto-set by GitLab):
| Variable | Example Value |
|---------|---------------|
| `CI_COMMIT_SHORT_SHA` | `a1b2c3d` |
| `CI_COMMIT_REF_NAME` | `main` |
| `CI_PIPELINE_ID` | `1234567` |
| `CI_PROJECT_NAME` | `gitlab-cicd-demo` |
| `CI_ENVIRONMENT_NAME` | `staging` or `production` |

### Custom variables (set in two ways):

**Method A – In the YAML file** (used above):
```yaml
variables:
  STAGING_URL: "https://staging.example.com"
```

**Method B – In GitLab UI (recommended for secrets)**:
1. Go to **Settings → CI/CD → Variables**.
2. Click **Add variable**.
3. Set `Key` = `DEPLOY_TOKEN`, `Value` = `your-secret-token`, check **Masked** ✅.
4. This variable is now available in all your pipeline jobs as `$DEPLOY_TOKEN`.

> **Best practice:** Never put secrets (passwords, API keys) directly in `.gitlab-ci.yml`. Always use **Masked Variables** in Settings.

---

## Task 5: Monitor Deployments and Pipeline History

### View Environments:
1. Go to **Operate → Environments** in the left sidebar.
2. You will see two rows: **staging** and **production**.
3. Each row shows:
   - **Last deployment** commit and timestamp.
   - **Environment URL** (clickable link).
   - **Re-deploy** button to re-run the last deployment.

### View Pipeline History:
1. Go to **Build → Pipelines**.
2. Each row is one pipeline run. Columns show:
   - **Status** – passed / failed / running.
   - **Pipeline ID** – click to open the graph.
   - **Trigger** – who triggered it (push, API, schedule, manual).
   - **Duration** – total time taken.
3. You can **cancel** a running pipeline or **retry** a failed one.

### View Deployment History per Environment:
1. Go to **Operate → Environments**.
2. Click **staging**.
3. The **Deployment history** section shows every deployment to staging, who triggered it, the commit, and the status.

---

## Full Pipeline Flow (Session 60 Summary)

```
git push → auto-trigger
         │
         ▼
 [build]  compile-and-package  ──► saves JAR artifact
         │
         ▼
 [test]   run-unit-tests       ──► publishes JUnit reports
         │
         ▼
 [deploy-staging]  deploy-staging  ──► auto runs (main branch only)
                                        environment: staging registered in GitLab
         │
         ▼ (PAUSED – waiting for manual approval)
 [deploy-production]  deploy-production ──► ▶ CLICK to approve manually
                                              environment: production registered
```

---

## ✅ Checklist

- [ ] Updated `.gitlab-ci.yml` with all 4 stages including `deploy-staging` and `deploy-production`
- [ ] `staging` environment visible under **Operate → Environments**
- [ ] `production` environment visible under **Operate → Environments**
- [ ] `deploy-production` job shows `▶ play` button (manual trigger) in pipeline graph
- [ ] Clicked the play button to manually approve and trigger production deployment
- [ ] Understood predefined CI variables (`CI_COMMIT_SHORT_SHA`, etc.)
- [ ] Added a custom CI variable in **Settings → CI/CD → Variables**
- [ ] Viewed deployment history under **Operate → Environments → staging**
- [ ] Reviewed pipeline history under **Build → Pipelines**
