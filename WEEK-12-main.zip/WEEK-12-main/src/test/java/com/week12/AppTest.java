package com.week12;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for App.java.
 * These tests are automatically run by the GitLab CI pipeline (Session 59).
 * Results are published as JUnit XML reports visible in the GitLab UI.
 */
class AppTest {

    private final App app = new App();

    @Test
    @DisplayName("Greeting message should not be null or empty")
    void testGetGreeting() {
        String greeting = app.getGreeting();
        assertNotNull(greeting, "Greeting must not be null");
        assertFalse(greeting.isEmpty(), "Greeting must not be empty");
        assertTrue(greeting.contains("GitLab"), "Greeting should mention GitLab");
    }

    @Test
    @DisplayName("Addition: 2 + 3 should equal 5")
    void testAdd() {
        assertEquals(5, app.add(2, 3), "2 + 3 should equal 5");
    }

    @Test
    @DisplayName("Addition: negative numbers should work correctly")
    void testAddNegative() {
        assertEquals(-1, app.add(2, -3), "2 + (-3) should equal -1");
    }

    @Test
    @DisplayName("isPositive: positive number returns true")
    void testIsPositiveTrue() {
        assertTrue(app.isPositive(10), "10 should be positive");
    }

    @Test
    @DisplayName("isPositive: zero is NOT positive")
    void testIsPositiveZero() {
        assertFalse(app.isPositive(0), "0 should not be positive");
    }

    @Test
    @DisplayName("Deploy target: staging environment")
    void testDeployTargetStaging() {
        String result = app.getDeployTarget("staging");
        assertTrue(result.contains("STAGING"), "Should include STAGING in result");
    }

    @Test
    @DisplayName("Deploy target: production environment")
    void testDeployTargetProduction() {
        String result = app.getDeployTarget("production");
        assertTrue(result.contains("PRODUCTION"), "Should include PRODUCTION in result");
    }

    @Test
    @DisplayName("Deploy target: unknown environment")
    void testDeployTargetUnknown() {
        String result = app.getDeployTarget("qa");
        assertTrue(result.contains("Unknown"), "Unknown environment should be flagged");
    }
}
