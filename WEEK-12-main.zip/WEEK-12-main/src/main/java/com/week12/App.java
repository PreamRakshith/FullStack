package com.week12;

/**
 * Sample application class used across GitLab CI/CD pipeline tasks.
 * The methods here are tested by AppTest and exercised by the CI pipeline.
 */
public class App {

    /**
     * Returns a greeting message. Used to verify the build is working.
     */
    public String getGreeting() {
        return "Hello from GitLab CI/CD Pipeline!";
    }

    /**
     * Adds two integers. Tested in Session 59 (Automated Build & Testing).
     */
    public int add(int a, int b) {
        return a + b;
    }

    /**
     * Checks if a number is positive.
     */
    public boolean isPositive(int number) {
        return number > 0;
    }

    /**
     * Simulates selecting an environment target.
     * Used to demonstrate CI variable usage in Session 60.
     */
    public String getDeployTarget(String env) {
        if ("production".equalsIgnoreCase(env)) {
            return "Deploying to PRODUCTION environment";
        } else if ("staging".equalsIgnoreCase(env)) {
            return "Deploying to STAGING environment";
        } else {
            return "Unknown environment: " + env;
        }
    }

    public static void main(String[] args) {
        App app = new App();
        System.out.println(app.getGreeting());
        System.out.println(app.getDeployTarget("staging"));
    }
}
