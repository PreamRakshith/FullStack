# Session 57 – GitLab CI + Git Integration

**Reference:** https://docs.gitlab.com/ee/ci/yaml/

---

## Objective

By the end of this session you will:
- Understand how GitLab's built-in SCM (Source Control Management) works.
- Create your first `.gitlab-ci.yml` file.
- Configure a basic pipeline with stages.
- See the pipeline automatically trigger on a commit.

---

## Task 1: Understand GitLab SCM (No External Git Tool Needed)

GitLab is a **complete DevOps platform** – its SCM is built in. Unlike original Git workflows that require external tools, GitLab provides:

| Feature | Where to find it in GitLab |
|---------|---------------------------|
| Branches | **Code → Branches** |
| Commits | **Code → Commits** |
| Merge Requests | **Code → Merge requests** |
| File editing | **Web IDE** (Edit → Web IDE) |
| Clone URL | **Code → Repository → Clone button** |

You can work entirely through the browser without installing Git on your machine.

---

## Task 2: Create `.gitlab-ci.yml` in the Repo Root

The `.gitlab-ci.yml` file is the **heart of GitLab CI**. It must be placed in the **root** of your repository (same level as `pom.xml` and `README.md`).

### Steps (using the GitLab Web IDE):

1. Inside your `gitlab-cicd-demo` project, click **Edit → Web IDE**.
2. In the file tree on the left, click the **+ (New file)** icon.
3. Name the file exactly: `.gitlab-ci.yml` (note the leading dot).
4. Paste the following content:

```yaml
# .gitlab-ci.yml – Session 57: Basic pipeline with stages
# Reference: https://docs.gitlab.com/ee/ci/yaml/

# 1. Define the stages (order matters – runs top to bottom)
stages:
  - build
  - test
  - deploy

# 2. Define a build job
build-job:
  stage: build
  script:
    - echo "=== BUILD STAGE ==="
    - echo "Compiling the application..."
    - echo "Build complete."

# 3. Define a test job
test-job:
  stage: test
  script:
    - echo "=== TEST STAGE ==="
    - echo "Running unit tests..."
    - echo "All tests passed!"

# 4. Define a deploy job
deploy-job:
  stage: deploy
  script:
    - echo "=== DEPLOY STAGE ==="
    - echo "Deploying to staging environment..."
    - echo "Deployment complete."
```

5. Click **Create commit** (bottom left).
6. Enter commit message: `Add .gitlab-ci.yml – Session 57 basic pipeline`.
7. Click **Commit to main branch**.

---

## Task 3: Understand the YAML Structure

Key `.gitlab-ci.yml` keywords used above:

| Keyword | Purpose |
|---------|---------|
| `stages` | Declares the order in which stages run. |
| `stage:` | Assigns a job to a specific stage. |
| `script:` | List of shell commands the runner executes. |

> **Important:** Every time you commit to `main`, GitLab **automatically** triggers the pipeline. No manual trigger needed.

---

## Task 4: Commit and Push Code to GitLab

(If you used the Web IDE in Task 2 above, the commit is already done.)

If using a local Git clone instead:

```bash
# Create .gitlab-ci.yml in your local clone folder
# Then:
git add .gitlab-ci.yml
git commit -m "Add .gitlab-ci.yml – Session 57 basic pipeline"
git push origin main
```

---

## Task 5: Observe the Automatic Pipeline Trigger

1. Go to your GitLab project.
2. Click **Build → Pipelines** in the left sidebar.
3. You should see a new pipeline row with status **running** or **passed**.
4. Click on the pipeline to open it.
5. You will see the **pipeline graph** showing three stage boxes: `build → test → deploy`.
6. Click any job (e.g., `build-job`) to see its log output.

### What you should see in the pipeline graph:
```
[build-job] ──► [test-job] ──► [deploy-job]
   ✅ passed       ✅ passed       ✅ passed
```

---

## ✅ Checklist

- [ ] Understood GitLab's built-in SCM features
- [ ] Created `.gitlab-ci.yml` in the repository root
- [ ] Configured 3 stages: `build`, `test`, `deploy`
- [ ] Committed the file (via Web IDE or `git push`)
- [ ] Observed the pipeline auto-triggered under **Build → Pipelines**
- [ ] Clicked into a job and viewed the log output
