# Session 56 – GitLab Account & UI Exploration

**Reference:** https://gitlab.com | https://docs.gitlab.com/ee/ci/

---

## Task 1: Create a GitLab Account

1. Open your browser and go to **https://gitlab.com**.
2. Click **Register now** (top-right).
3. Fill in:
   - **Full Name** – your name.
   - **Username** – choose a unique username (e.g., `john_doe_dev`). This appears in all your repo URLs.
   - **Email** – use a valid email you have access to.
   - **Password** – minimum 8 characters.
4. Complete the CAPTCHA and click **Register**.
5. Check your email inbox for a **confirmation email** from GitLab. Click the link inside to verify.
6. Log in at https://gitlab.com with your new credentials.

> **Tip:** If you already have a GitHub account, you can use **Continue with GitHub** on the login page to create a linked GitLab account instantly.

---

## Task 2: Explore the GitLab UI

Once logged in, spend a few minutes navigating the interface:

### 2.1 – Dashboard (Home)
- The **left sidebar** is your main navigation.
- **Your work** shows activity, merge requests, issues, and projects.
- The **top bar** gives access to search, notifications, and your profile.

### 2.2 – Projects
- Click **Your work → Projects** in the left sidebar.
- You will see a list of your projects (empty right now).
- Key buttons:
  - **New project** – creates a brand new repository.
  - **Star** – bookmarks a project.

### 2.3 – Repositories (inside a project)
- Inside any project, click **Code → Repository** in the left sidebar.
- This shows the **file browser** for the repo, similar to GitHub's code tab.
- Key features:
  - **Branches** dropdown – switch between branches.
  - **+ (Add file)** button – create or upload files directly from the browser.
  - **Clone** button – copy the HTTPS or SSH URL.

### 2.4 – CI/CD Section
- Inside a project, click **Build → Pipelines** in the left sidebar.
- This is where all pipeline runs appear after you add a `.gitlab-ci.yml` file.
- Key sub-pages:
  - **Pipelines** – list of all pipeline runs.
  - **Jobs** – individual job executions with logs.
  - **Schedules** – trigger pipelines on a cron schedule.
  - **Runners** – see which runners are available (shared vs. project-specific).

---

## Task 3: Create a New GitLab Project

1. Click **+ New project** from the top-right or from the Projects page.
2. Choose **Create blank project**.
3. Fill in:
   - **Project name:** `gitlab-cicd-demo`
   - **Project slug:** auto-filled (e.g., `gitlab-cicd-demo`).
   - **Visibility Level:** choose **Public** (recommended for learning; lets shared runners work freely).
   - Check **"Initialize repository with a README"** ✅ (this creates a `main` branch immediately).
4. Click **Create project**.

You will be redirected to your new repository.

---

## Task 4: Push Sample Code to the Repository

You have two options:

### Option A: Using GitLab Web IDE (no Git needed)

1. Inside your project, click **Edit → Web IDE** (or the blue **Edit** dropdown on a file).
2. Click **New file** → name it `App.java` and paste the contents from `src/main/java/com/week12/App.java` in this project.
3. Click **Create commit** → commit directly to `main`.

### Option B: Using Git on your machine

```bash
# Clone the repository
git clone https://gitlab.com/<YOUR_USERNAME>/gitlab-cicd-demo.git
cd gitlab-cicd-demo

# Copy files from this Eclipse project into the cloned folder, then:
git add .
git commit -m "Initial commit: add sample Java application"
git push origin main
```

---

## Task 5: Key CI/CD Concepts to Know

| Concept   | Explanation |
|-----------|-------------|
| **Pipeline** | The overall automated workflow triggered by a git push. Defined in `.gitlab-ci.yml`. |
| **Stage**    | A logical group of jobs that run together (e.g., `build`, `test`, `deploy`). Stages run sequentially. |
| **Job**      | A single script/task inside a stage. Jobs within the same stage run in parallel. |
| **Runner**   | The virtual machine/container that actually executes your jobs. GitLab provides **shared runners** for free on public projects. |
| **Artifact** | A file or folder produced by a job that is saved and can be downloaded or passed to the next stage. |

**Pipeline execution order:**
```
PUSH to GitLab → Pipeline triggered → Stage 1 (build) → Stage 2 (test) → Stage 3 (deploy) → Done
```

---

## ✅ Checklist

- [ ] GitLab account created and email verified
- [ ] Dashboard, Projects, and CI/CD sections explored
- [ ] New project `gitlab-cicd-demo` created (public, with README)
- [ ] Sample code pushed / added via Web IDE
- [ ] Understood: Pipeline, Stage, Job, Runner, Artifact
