package com.cloud.task13_4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Task134Application {
    public static void main(String[] args) {
        SpringApplication.run(Task134Application.class, args);
        System.out.println("Task 13.4 RDS Application Started!");
    }
}
