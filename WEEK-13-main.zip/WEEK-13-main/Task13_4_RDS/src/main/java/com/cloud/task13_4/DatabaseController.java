package com.cloud.task13_4;

import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/database")
public class DatabaseController {

    @GetMapping("/status")
    public Map<String, Object> getDatabaseStatus() {
        Map<String, Object> status = new HashMap<>();
        status.put("dbIdentifier", "healthtrack-db");
        status.put("state", "AVAILABLE");
        status.put("endpoint", "healthtrack-db.xyz.us-east-1.rds.amazonaws.com");
        status.put("backups", "Enabled (1 day retention)");
        status.put("maintenance", "Scheduled (Sun 00:00 UTC)");
        return status;
    }

    @PostMapping("/verify-connection")
    public String verifyConnection() {
        return "Successfully connected to RDS instance. Ready to store HealthTrack data.";
    }
}
