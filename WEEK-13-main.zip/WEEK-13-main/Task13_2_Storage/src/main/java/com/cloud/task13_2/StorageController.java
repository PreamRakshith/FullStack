package com.cloud.task13_2;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/storage")
public class StorageController {

    @GetMapping("/details")
    public Map<String, Object> getStorageDetails() {
        Map<String, Object> response = new HashMap<>();
        response.put("status", "Active");
        response.put("provider", "Azure Blob Storage");
        response.put("container", "project-files");
        response.put("owner", "Arun");
        response.put("message", "Files: project_report.pdf, image1.jpg uploaded successfully.");
        return response;
    }
}
