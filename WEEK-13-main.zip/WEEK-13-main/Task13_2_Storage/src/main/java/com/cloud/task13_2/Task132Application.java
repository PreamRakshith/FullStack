package com.cloud.task13_2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Task132Application {
    public static void main(String[] args) {
        SpringApplication.run(Task132Application.class, args);
        System.out.println("Task 13.2 Storage Application Started!");
    }
}
