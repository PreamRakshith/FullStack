package com.cloud.task13_1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Task131Application {
    public static void main(String[] args) {
        SpringApplication.run(Task131Application.class, args);
        System.out.println("Task 13.1 Serverless Application Started!");
    }
}
