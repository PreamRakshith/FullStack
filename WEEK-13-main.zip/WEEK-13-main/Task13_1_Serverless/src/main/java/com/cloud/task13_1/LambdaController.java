package com.cloud.task13_1;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class LambdaController {

    @GetMapping("/hello")
    public Map<String, Object> helloLambda() {
        Map<String, Object> response = new HashMap<>();
        response.put("message", "Hello from Spring Boot (Triggering Lambda logic)!");
        response.put("task", "Task 13.1 - Serverless API Gateway");
        response.put("status", "Integration Ready");
        return response;
    }
}
