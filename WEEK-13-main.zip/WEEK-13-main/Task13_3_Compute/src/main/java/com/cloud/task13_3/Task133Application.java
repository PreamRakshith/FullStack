package com.cloud.task13_3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Task133Application {
    public static void main(String[] args) {
        SpringApplication.run(Task133Application.class, args);
        System.out.println("Task 13.3 Compute Application Started!");
    }
}
