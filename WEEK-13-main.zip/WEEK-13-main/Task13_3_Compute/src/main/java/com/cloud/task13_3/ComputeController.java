package com.cloud.task13_3;

import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/compute")
public class ComputeController {

    @PostMapping("/instance/create")
    public String createInstance() {
        return "EC2 Instance 'MyLearningVM' (t2.micro) launch command initiated.";
    }

    @GetMapping("/instance/status")
    public Map<String, String> getStatus() {
        Map<String, String> status = new HashMap<>();
        status.put("instanceId", "i-0abcdef1234567890");
        status.put("state", "RUNNING");
        return status;
    }

    @PostMapping("/instance/stop")
    public String stopInstance() {
        return "EC2 Instance stop command sent to save costs.";
    }
}
