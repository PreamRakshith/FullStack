package com.cloud.task13_5;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class AnalysisController {

    @GetMapping("/analysis")
    public Map<String, Object> getEduFlexAnalysis() {
        Map<String, Object> analysis = new HashMap<>();
        analysis.put("startup", "EduFlex");
        analysis.put("model", "Pay-As-You-Use");
        
        List<String> benefits = new ArrayList<>();
        benefits.add("No Upfront Cost (CapEx)");
        benefits.add("Automatic Elasticity (200 to 10,000 users)");
        benefits.add("Operational Efficiency");
        analysis.put("benefits", benefits);

        Map<String, String> costEstimates = new HashMap<>();
        costEstimates.put("Normal Days (200 users)", "$1-2/day");
        costEstimates.put("Peak Days (10,000 users)", "$15-20/day");
        analysis.put("costComparison", costEstimates);

        return analysis;
    }
}
