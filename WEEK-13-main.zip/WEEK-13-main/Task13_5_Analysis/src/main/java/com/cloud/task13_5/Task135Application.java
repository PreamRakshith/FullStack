package com.cloud.task13_5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Task135Application {
    public static void main(String[] args) {
        SpringApplication.run(Task135Application.class, args);
        System.out.println("Task 13.5 Analysis Application Started!");
    }
}
